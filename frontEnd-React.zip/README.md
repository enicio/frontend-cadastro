Para rodar o projeto primeiro rode o comando 

npm install

Apos concluir inicie com

yarn start

