Para rodar o projeto primeiro rode o comando 

npm install

Apos concluir inicie com

yarn start

O primeiro login apos a aplicação ser iniciada deve ser com 
usuário Admin e senha Admin.

